# -*- coding: utf-8 -*-
import modules.entity as entity
from modules.entity import AllEntities
import modules.items as items
import re
from modules.items import AllItems
import modules.location as location
import modules.errors as errors
import sys
from colorama import init
from saves_manager import *
from rich.console import Console
from modules.magic_raw import *
from time import sleep

AllItems = AllItems()
init()

LEN_LINE = 15 * 3
console = Console()
name = "RPG"
TITLE = f"""
{"[bold red] ┏━━━━━━━━━━━┓  "}{"[bold blue] ┏━━━━━━━━━━━┓ "}{"[bold yellow] ┏━━━━━━━━━━━┓  "}
{"[bold red] ┃   ┏━━━━┓  ┃  "}{"[bold blue] ┃   ┏━━━━━┓ ┃ "}{"[bold yellow] ┃   ┏━━━━━━━┛  "}
{"[bold red] ┃   ┗━━━━┛  ┃  "}{"[bold blue] ┃   ┗━━━━━┛ ┃ "}{"[bold yellow] ┃   ┃          "}
{"[bold red] ┃   ━━━━━━┓━┛  "}{"[bold blue] ┃   ┏━━━━━━━┛ "}{"[bold yellow] ┃   ┃ ┏━━━━━┓  "}
{"[bold red] ┃   ┏━━━┓ ┗━━┓ "}{"[bold blue] ┃   ┃         "}{"[bold yellow] ┃   ┃ ┗━━━┓ ┃  "}
{"[bold red] ┃   ┃   ┗━┓  ┃ "}{"[bold blue] ┃   ┃         "}{"[bold yellow] ┃   ┗━━━━━┛ ┃  "}
{"[bold red] ┗━━━┛     ┗━━┛ "}{"[bold blue] ┗━━━┛         "}{"[bold yellow] ┗━━━━━━━━━━━┛  "}

"""


class Input:
    def __init__(self, text: str, stop=lambda x: x != x, correct=lambda x: x == x):
        """
        Class for inputing means from console
        Parameters:
        - `text` str text that will be in input
        - `stop` function if it is true while will stop
        - `correct` lambda is cheacking mean before return
        """
        while True:
            self._input = str(console.input(text))
            if stop(self._input):
                break
            elif correct(self._input):
                break

    def __int__(self):
        return int(self._input)

    def __str__(self):
        return str(self._input)


LOADSAVE = "load"
LASTSAVE = "last"
NEWSAVE = "new"
EXIT = "exit"
INV = "inv"
MAP = "map"
SKILLS = "skills"
LOCS = "locs"
GO = "go"
MAP = "map"
SAVE = "save"
QUIT = "quit"
TALK = "talk"
FIGHT = "fight"

# Make locations
shop = location.Location(
    "Магазин",
    {AllEntities.moat_npc.name: AllEntities.moat_npc},
    2,
    "Магазин полезных вещей",
)
tram = location.Location(
    "Трамвай", {}, 0, "Трамвайная дорога проложенная с давних времён..."
)
tram_station = location.Location(
    "Трамвайная станция", {}, 0, "", underlocs={tram.name: tram}
)

the_crossroads = location.Location(
    "Перепутье",
    {AllEntities.fire_boss.name: AllEntities.fire_boss},
    1,
    "Подземная дорога что ведёт в глубины королевства...",
    underlocs={shop.name: shop, tram_station.name: tram_station},
)
tram.parent = tram_station
tram_station.parent = the_crossroads
shop.parent = the_crossroads

names_dict = location.locations_dict
ent_names_dict = entity.entities_dict

commands1 = [
    "exit",
    "help",
    "new",
    "last",
    "load"
]
commands2 = [
    "exit",
    "help",
    "skills",
    "save",
    "inv",
    "map",
    "locs",
    "go",
    "quit",
    "talk",
    "fight",
]

LOCATION = the_crossroads

def animated_title():
    console.print(TITLE)
    string = "="*45
    for i in range(43):
        sys.stdout.write('\033[1;35m'+string[:i+1]+'\033[0m\033[1;37m'+string[i+1:]+"\r")
        sleep(0.07)
    console.print("[bold blue]=============================================")
    sleep(1)


class Game:
    def __init__(self):
        animated_title()
        console.print(f"[bold green]Привет добро пожаловать в Console[/bold green] [bold red]{name[0]}[/bold red][bold blue]{name[1]}[/bold blue][bold yellow]{name[2]}[/bold yellow][bold green] Game! Загрузи сохранение или создай новое.\r")
        self.main_menu()
        self.pattern = re.compile(r"""^[0-9а-яА-ЯёЁa-zA-Z]+$""")
        while True:
            self.choice = str(
                Input("[bold red]> ", correct=lambda x: str(x).lower() in commands1)
            )
            if self.choice == LOADSAVE:
                console.print("[bold green]Введите название сохранения[/bold green] ([red]e[/red] - отмена)")
                self.save_name = str(
                    Input(
                        text="[bold red]> ",
                        correct=lambda x: self.pattern.search(str(x)),
                    )
                )
                save_name_cheack = [False]
                if self.save_name in saves_list():
                    save_name_cheack[0] = True
                else:
                    if self.save_name.lower() != 'e':
                        console.print("[bold red]Сохранение не найдено")
                
                if all(save_name_cheack) and self.save_name != 'e':
                    load_game_result = load_game(self.save_name)
                    if not type(load_game_result) is dict:
                        raise errors.SaveIsNotDictError(f"Save '{self.save_name}' isn`t dict")
                    else:
                        self.object_save = load_game_result["save"]
                        self.player = load_game_result["player"]
                        console.print(f'[bold green]Загружено сохранение {self.save_name}')

                        self.save = Save(self.player, self.object_save.total_location, self.save_name)
                        break
                else:
                    console.print('[bold red]Отменено')

            elif self.choice == NEWSAVE:
                console.print("[bold green]Введите название сохранения[/bold green] ([red]e[/red] - отмена)")
                self.save_name = str(
                    Input(
                        text="[bold red]> ",
                        correct=lambda x: self.pattern.search(str(x).lower()) and not x in saves_list() or str(x) == 'e',
                    )
                )
                if self.save_name != 'e':
                    self.player = Player(
                        xp=10.0,
                        damage=0.1,
                        name="Рыцарь",
                        armors=[AllItems.busic_shell],
                        soul_count=TheSoul(0.5),
                        void_count=TheVoid(50),
                        description="[bold white]Рыцарь, не помнящий ничего...",
                        block_damage=0.2,
                        skills={"X": (AllItems.old_sword, "Удар гвоздём"),
                        "C": (AllItems.basic_shield, "Щит")},
                        items=[AllItems.old_sword, AllItems.cape, AllItems.busic_shell, AllItems.basic_shield],
                    )
                    self.save = Save(self.player, the_crossroads, self.save_name)
                    break
                else:
                    console.print('[bold red]Отменено')

            elif self.choice == LASTSAVE:
                self.save_name = last_save_name()
                if self.save_name:
                    try:
                        load_game_result = load_game(self.save_name)
                        if not type(load_game_result) is dict:
                            raise errors.SaveIsNotDictError(f"Save '{self.save_name}' isn`t dict")
                        else:
                            self.object_save = load_game_result["save"]
                            self.player = load_game_result["player"]
                            console.print(f'[bold green]Загружено сохранение {self.save_name}')
                            self.save = Save(self.player, self.object_save.total_location, self.save_name)
                            break
                    except errors.NoDefinedSaveError:
                        console.print('[bold red]Ошибка нету последнего сохранения')
                        continue
                else:
                    console.print('[bold red]Ошибка нету последнего сохранения')
                    continue



    def main_menu(self):
        for ch in (
            "[blue]load[/blue] - Загрузить сохранение",
            "[blue]last[/blue] - Последние сохранение",
            " [blue]new[/blue] - Новое сохранение",
            "[blue]exit[/blue] - Выход (Ctrl+C)",
        ):
            console.print(ch)


class Player(entity.PlayableEntity):
    def __init__(
        self,
        xp: float,
        damage: float,
        name: str,
        armors: list or tuple,
        soul_count: TheSoul,
        void_count: TheVoid,
        items: list,
        skills: dict,
        description,
        block_damage,
    ):
        # Init params
        self.xp = xp
        self.full_xp = xp
        self.damage = damage
        self.name = name
        self.armors = armors
        self.soul_count = soul_count
        self.void_count = void_count
        self.description = description
        self.skills = skills
        self.items = {k : v for (k, v) in zip(
            [item.name for item in items],
            items
        )}
        print(self.items)

        # Reinit params with changes
        self.block_damage = block_damage
        for armor in self.armors:
            self.block_damage = self.block_damage + armor.block_damage
        

    def __doc__(self):
        return str(self.description)


class Save():
    def __init__(self, player, total_location, save_name):
        self.save_name = save_name
        self.total_location = total_location
        self.player = player
        self.main()

    def main(self):
        # Modules settings
        items.player = self.player
        console.print(self.player.__doc__())
        save_game(self.save_name, {
            "player":self.player,
            "save"  :self
        })
        correct_command = lambda: len(self.choice.split(" ")) >= 2
        correct_command2 = lambda: len(self.choice.split(" ")) == 1
        while True:
            # Выводим меню
            self.menu()
            self.command = self.choice.lower().split(" ")[0]
            
            if self.command == INV and correct_command2():  # Вещи
                self.inventory(self.player)  # Открыть инвентарь
            elif self.command == LOCS and correct_command2():  # Локации
                self.show_locations()  # Показать локации
            elif self.command == SKILLS and correct_command2(): # Способности
                self.show_skills(self.player) # Показать способности
            elif self.command == SAVE and correct_command2():
                save_game(self.save_name, {
                    "player":self.player,
                    "save"  :self
                })
                console.print("[bold green]Сохранено")

            elif self.command == TALK and correct_command():  # Поговорить
                self.arg = str(self.choice).lower().split(" ")[1]
                self.talk(self.arg)
            elif self.command == FIGHT and correct_command():  # Сразится
                self.arg = str(self.choice).lower().split(" ")[1]
                self.fight(self.arg)
            elif self.command == QUIT and correct_command2():
                if not isinstance(self.total_location.parent, location.BasicLocation):
                    self.total_location = self.total_location.parent
                self.show_locations()
            elif self.command == GO and correct_command():
                self.arg = str(self.choice).lower().split(" ")[1]
                print(self.total_location.names.keys())
                if self.arg in self.total_location.names.keys():
                    self.total_location = names_dict[
                        self.total_location.names[self.arg].name
                    ]
                    self.show_locations()
                else:
                    console.print("[bold red]Введено неверное число")
                    self.show_locations()
            elif self.command == EXIT and correct_command2():
                raise KeyboardInterrupt
    def show_skills(self, _entity: entity.PlayableEntity or entity.NotPlayableEntity):
        d = str()
        for skill_name in _entity.skills:
            console.print(
                f"[bold white]{_entity.skills[skill_name][0].name}[/bold white] - [blue]{skill_name}.[/blue] [yellow]{_entity.skills[skill_name][1]}[/yellow]"
            )
            d += f"{skill_name} - {_entity.skills[skill_name][0].name}. {_entity.skills[skill_name][1]},\n"
        return d

    def _exit(self):
        print("^C")
        console.print("[bold red]Вы действительно хотите выйти?[/bold red][y/n]")
        is_exit = str(
            Input(text="[bold red]> ", correct=lambda x: str(x).lower() in ("y", "n"))
        )
        if is_exit.lower() == "y":
            save_game(self.save_name, {
                "player":self.player,
                "save"  :self
            })
            console.log("[bold green]Сохранено")

        elif is_exit.lower() == "n":
            pass

    def correct_attack(self, attack: str):
        if len(attack) <= 2:
            result = False
            for n in attack.upper():
                if n in self.player.skills:
                    result = True
                else:
                    result = False
            return result
        else:
            return False


    def fight(self, entity_name):
        if self.arg in self.total_location.ent_names:
            if (
                self.total_location.ent_names[self.arg].identifier
                == entity.EntType.BOSS
            ):
                enemy = self.total_location.ent_names[entity_name]
                enemy.start_dialog()
                console.print(
                    f"[bold white]Сразится с [bold red]{enemy.name}[/bold red]? [y/n]"
                )
                answer = str(
                    Input(
                        text="[bold red]> ",
                        correct=lambda x: str(x) in ("y", "n"),
                    )
                )
                if answer == "y":
                    console.print(self.show_skills(self.player) + ' Ваши способности')
                    console.print(self.show_skills(enemy) + ' Способности врага')
                    console.print(
                        f"[bold red]Введите аттаку[/bold red]\n"
                    )
                    while not enemy.xp <= 0:
                        self.attack = str(
                            Input(
                                text="[bold red]> ",
                                correct=lambda x: str(x).upper()
                                in self.player.skills,
                            )
                        ).upper()
                        enemy.update_attack()
                        for atk in self.attack:
                            console.print('[bold green]Вы:', self.player.skills[atk][0].name)
                            console.print('[bold green]Враг:', enemy.skills[enemy.attack][0].name)
                            if isinstance(self.player.skills[atk][0], items.Shield) and not isinstance(self.player.skills[atk][0], items.Skill):
                                console.print("[bold white]Вы отразили удар")
                            else:
                                if isinstance(enemy.skills[enemy.attack][0], items.Shield) and isinstance(self.player.skills[atk][0], items.Weapon):
                                    console.print("[bold white]Противник отразил удар")
                                elif isinstance(self.player.skills[atk][0], items.Skill) and isinstance(enemy.skills[enemy.attack][0], items.Weapon):
                                    if enemy.skills[enemy.attack][0].name in [ref.name for ref in self.player.skills[atk][0].reflecs]:
                                        console.print("[bold white]Вы увернулись")
                                elif not isinstance(self.player.skills[atk][0], items.Skill):
                                    a = enemy.hit(self.player.skills[atk][0])
                                    b = self.player.hit(enemy.skills[enemy.attack][0])
                                    console.print(
                                        f"Вы нанесли: {a[1]}\t {round(enemy.xp, 1)}/{round(enemy.full_xp, 1)}"
                                    )
                                    console.print(
                                        f"Вам нанесли: {b[1]}\t {round(self.player.xp, 1)}/{round(self.player.full_xp, 1)}"
                                    )
                                    if self.player.xp <= 0:
                                        break
                            
                                

                    else:
                        enemy.death_event(enemy.after_death)
                        console.print(
                            f"[bold yellow]Вы победили[/bold yellow] [bold red]{enemy.name}"
                        )
                        console.print(
                            f"[bold white]Вы получили {enemy.drop.name}[/bold white] [bold yellow]{enemy.drop.description}"
                        )
                        enemy.drop.received()
                        self.player.items[enemy.drop.name] = enemy.drop
                        del self.total_location.entities[enemy.name]

    def talk(self, entity_name):
        if self.total_location.ent_names[entity_name].identifier == entity.EntType.NPC:
            self.total_location.ent_names[entity_name].start_dialog()

    def show_locations(self):
        # Показать текущию
        console.print(
            f"[bold green]Текущая локация[/bold green][bold white] {self.total_location.name}"
        )
        # Если есть подлокации
        if self.total_location.underlocs != dict():
            
            # Показать подлокации
            console.print("[bold green]Подлокации[/bold green]")
            self.loc_index = 0
            for num in self.total_location.names: # Циклом перебераем подлокации
                console.print(
                    f"[blue]{num}[/blue][bold white] - {self.total_location.names[num].name}[/bold white] [bold yellow]{self.total_location.names[num].description}[/bold yellow]"
                )
                self.loc_index += 1

            if not isinstance(self.total_location.parent, location.BasicLocation):
                console.print(
                    f"[blue]quit[/blue][bold white] - {self.total_location.parent.name}[/bold white] (Выход)"
                )
        # Вывод существ
        # Проверяем, есть ли существа в текущей локации
        if self.total_location.entities != dict():
            console.print(f"[bold green]Существа")
            for num, name in enumerate(self.total_location.entities, 1):
                ent = self.total_location.entities[name]
                console.print(
                    f"[blue]{num}[/blue][bold white] - {ent.name}[/bold white] [bold yellow]{ent.description}[/bold yellow]"
                )

    def inventory(self, _entity: entity.PlayableEntity or entity.NotPlayableEntity):
        console.print("[bold green]Вещи")
        for item_name in _entity.items:
            console.print(
                f"[bold white]{item_name}[/bold white] [blue]{_entity.items[item_name].description}.[/blue]\
                    [yellow]{_entity.items[item_name].interesting}[/yellow]"
            )

    def menu(self):
        for ch in (
            "   [blue]inv[/blue] - Вещи              (inv)",
            "  [blue]locs[/blue] - Доступные локации (locs)",
            "[blue]skills[/blue] - Навыки            (skills)",
            "  [blue]talk[/blue] - Поговорить        (talk <номер персонажа>)",
            " [blue]fight[/blue] - Сразиться         (fight)",
            "  [blue]save[/blue] - Сохранить         (save)",
            "    [blue]go[/blue] - Переместиться     (go <номер локации>)",
            "  [blue]exit[/blue] - Выход (Ctrl+C)    (выход)",
            "  [blue]quit[/blue] - Выйти назад в предыдущию локацию"
        ):
            console.print(ch)
        self.choice = str(
            Input(
                "[bold red]> ",
                correct=lambda x: str(x).lower().split(" ")[0]
                in commands2
                + [str(ch) for ch in range(1, len(self.total_location.names))],
            )
        ).lower()


if __name__ == "__main__":
    while True:
        try:
            game = Game()
        except KeyboardInterrupt:
            print("^C")
            console.print("[bold red]Вы действительно хотите выйти?[/bold red][y/n]")
            is_exit = str(
                Input(
                    text="[bold red]> ", correct=lambda x: str(x).lower() in ("y", "n")
                )
            )
            if is_exit.lower() == "y":
                break

            elif is_exit.lower() == "n":
                continue
