# -*- coding: utf-8 -*-
import modules.entity as entity
from modules.entity import AllEntities
import modules.items as items
import re
from modules.items import AllItems
import modules.location as location
import modules.errors as errors
import sys
from colorama import init
from saves_manager import *
from modules.magic_raw import *
import modules.settings_importer as importer
from time import sleep
from rich.console import Console
from modules.currency import Currency as c 

AllItems = AllItems()
importer.load_settings()       
console = Console()
init()
name = "RPG"

LEN_LINE = 15 * 3
TITLE = f"""
{"[bold red] ┏━━━━━━━━━━━┓  "}{"[bold blue] ┏━━━━━━━━━━━┓ "}{"[bold yellow] ┏━━━━━━━━━━━┓  "}
{"[bold red] ┃   ┏━━━━┓  ┃  "}{"[bold blue] ┃   ┏━━━━━┓ ┃ "}{"[bold yellow] ┃   ┏━━━━━━━┛  "}
{"[bold red] ┃   ┗━━━━┛  ┃  "}{"[bold blue] ┃   ┗━━━━━┛ ┃ "}{"[bold yellow] ┃   ┃          "}
{"[bold red] ┃   ━━━━━━┓━┛  "}{"[bold blue] ┃   ┏━━━━━━━┛ "}{"[bold yellow] ┃   ┃ ┏━━━━━┓  "}
{"[bold red] ┃   ┏━━━┓ ┗━━┓ "}{"[bold blue] ┃   ┃         "}{"[bold yellow] ┃   ┃ ┗━━━┓ ┃  "}
{"[bold red] ┃   ┃   ┗━┓  ┃ "}{"[bold blue] ┃   ┃         "}{"[bold yellow] ┃   ┗━━━━━┛ ┃  "}
{"[bold red] ┗━━━┛     ┗━━┛ "}{"[bold blue] ┗━━━┛         "}{"[bold yellow] ┗━━━━━━━━━━━┛  "}
"""
class Input:
    def __init__(self, text: str, stop=lambda x: x != x, correct=lambda x: x == x):
        """
        Class for inputing means from console
        Parameters:
        - `text` str text that will be in input
        - `stop` function if it is true while will stop
        - `correct` lambda is cheacking mean before return
        """
        while True:
            self._input = str(console.input(text))
            if stop(self._input):
                break
            elif correct(self._input):
                break

    def __int__(self):
        return int(self._input)

    def __str__(self):
        return str(self._input) 

def the_small_canyon_on_try_quit(obj):
    console.print('[bold white]Слишком высоко! Мне не забраться наверх.')
    sleep(1)
def the_old_town_on_into(obj):
    sleep(1)
    console.print('Город. Вы можете поговорить с жителями')
    sleep(1)
def the_small_canyon_on_located(obj):
    obj.total_location = the_crack
    console.print('[bold white]Какой каньон! Как бы не свалиться....')
    sleep(2)
    console.print('[bold white]Вжииик!')
    sleep(1)
    console.print('[bold white]Вы упали в каньон.')
    sleep(5)
    console.print('[bold white]Ох! Где это я?')
    sleep(1)
    console.print('Вы оказались в расщелине.')
    sleep(1)
    console.print('Вы идёте вперёд....')
    obj.total_location = the_old_town

LOADSAVE      = "load"
LASTSAVE      = "last"
OPEN_SETTINGS = "options"
NEWSAVE       = "new"
EXIT          = "exit"
INV           = "inv"
MAP           = "map"
SKILLS        = "skills"
LOCS          = "locs"
GO            = "go"
MAP           = "map"
SAVE          = "save"
QUIT          = "quit"
TALK          = "talk"
FIGHT         = "fight"
HELP          = "help"
CREDITS       = "credits"


the_lond_hallway = location.Location("Длинная галерея", {}, 3, "")
the_crossroads = location.Location("Запутанное перепутье", {AllEntities.test_boss.name:AllEntities.test_boss}, 1, "Подземная дорога что ведёт в глубины королевства...",underlocs={the_lond_hallway.name:the_lond_hallway})
the_shop1 = location.Location("Магазин", {AllEntities.moat_seiler.name:AllEntities.moat_seiler}, 0, "Магазин полезных вещей")
the_old_town = location.Location('Город ветров', {AllEntities.oldman_npc.name:AllEntities.oldman_npc}, 1, 'Угасающий город', underlocs={the_crossroads.name:the_crossroads, the_shop1.name:the_shop1}, on_into_func=the_old_town_on_into)
the_crack = location.Location('Расщелина', {}, 3, 'Ничего, кроме пары кусочков мха', underlocs={the_old_town.name:the_old_town})
the_small_canyon = location.Location('Малый каньон', {}, 3, 'Глубокая трешина, рядом с которой осторожность не помешает', underlocs={the_crack.name:the_crack}, located_func=the_small_canyon_on_located, quitable=False, on_try_quit=the_small_canyon_on_try_quit)
test = location.Door("namememe", AllItems.nail_pick, underloc=the_small_canyon)
the_pass = location.Location('Перевал королевства', {}, 1, 'Подземный перевал рядом', underlocs={the_small_canyon.name:the_small_canyon, test.name:test})

test.parent = the_pass
the_shop1.parent = the_old_town
the_lond_hallway.parent = the_crossroads
the_crossroads.parent = the_old_town
the_old_town.parent = the_crack
the_crack.parent = the_small_canyon
the_small_canyon.parent = the_pass

names_dict = location.locations_dict
ent_names_dict = entity.entities_dict

commands1 = [
    "exit",
    "help",
    "new",
    "credits",
    "last",
    "load",
    "options"
]
commands2 = [
    "exit",
    "help",
    "skills",
    "save",
    "inv",
    "map",
    "locs",
    "go",
    "quit",
    "talk",
    "fight",
    "help"
]
commands3 = [
    "set",
    "def",
    "defall",
    "save_exit"
]

LOCATION = the_pass



def animated_title():
    if importer.settings["play_animation"]:
        console.print(TITLE)
        string = "="*45
        for i in range(43):
            sys.stdout.write('\033[1;35m'+string[:i+1]+'\033[0m\033[1;37m'+string[i+1:]+"\r")
            sleep(0.07)
        console.print("[bold blue]=============================================")
        sleep(1)
    else:
        console.print(TITLE)
        console.print("[bold blue]=============================================")



class Game:
    def __init__(self):
        animated_title()
        console.print(f"[bold green]Привет добро пожаловать в Console[/bold green] [bold red]{name[0]}[/bold red][bold blue]{name[1]}[/bold blue][bold yellow]{name[2]}[/bold yellow][bold green] Game! Загрузи сохранение или создай новое.\r")
        self.main_menu()
        self.pattern = re.compile(r"""^[0-9а-яА-ЯёЁa-zA-Z]+$""")
        while True:
            self.choice = str(
                Input("[bold red]> ", correct=lambda x: str(x).lower() in commands1)
            )
            if self.choice == LOADSAVE:
                console.print("[bold green]Введите название сохранения[/bold green] ([red]e[/red] - отмена)")
                self.save_name = str(
                    Input(
                        text="[bold red]> ",
                        correct=lambda x: self.pattern.search(str(x)),
                    )
                )
                save_name_cheack = [False]
                if self.save_name in saves_list():
                    save_name_cheack[0] = True
                else:
                    if self.save_name.lower() != 'e':
                        console.print("[bold red]Сохранение не найдено")
                 
                if all(save_name_cheack) and self.save_name != 'e':
                    load_game_result = load_game(self.save_name)
                    if not type(load_game_result) is dict:
                        raise errors.SaveIsNotDictError(f"Save '{self.save_name}' isn`t dict")
                    else:
                        self.object_save = load_game_result["save"]
                        console.print(f'[bold green]Загружено сохранение {self.save_name}')

                        self.save = Save(self.object_save.player, self.object_save.total_location, self.save_name)
                        break
                else:
                    console.print('[bold red]Отменено')
            elif self.choice == CREDITS:
                self.credits()

            elif self.choice == NEWSAVE:
                console.print("[bold green]Введите название сохранения[/bold green] ([red]e[/red] - отмена)")
                self.save_name = str(
                    Input(
                        text="[bold red]> ",
                        correct=lambda x: self.pattern.search(str(x).lower()) and not x in saves_list() or str(x) == 'e',
                    )
                )
                if self.save_name != 'e':
                    self.player = Player(
                        xp=10.0,
                        damage=0.1,
                        name="Рыцарь",
                        armors=[AllItems.busic_shell],
                        soul_count=TheSoul(0.5),
                        void_count=TheVoid(50),
                        currency_count=c(1000000),
                        description="[bold white]Рыцарь, не помнящий ничего...",
                        block_damage=0,
                        skills={"X": (AllItems.old_sword, "Удар гвоздём"),
                        "C": (AllItems.basic_shield, "Щит"), "T": (AllItems.jump_skill, "Прыжок")},
                        items=[AllItems.old_sword, AllItems.cape, AllItems.busic_shell, AllItems.basic_shield],
                    )
                    self.save = Save(self.player, LOCATION, self.save_name)
                else:
                    console.print('[bold red]Отменено')

            elif self.choice == LASTSAVE:
                self.save_name = last_save_name()
                if self.save_name:
                    try:
                        load_game_result = load_game(self.save_name)
                        if not type(load_game_result) is dict:
                            raise errors.SaveIsNotDictError(f"Save '{self.save_name}' isn`t dict")
                        else:
                            self.object_save = load_game_result["save"]
                            self.player = load_game_result["player"]
                            console.print(f'[bold green]Загружено сохранение {self.save_name}')
                            self.save = Save(self.player, self.object_save.total_location, self.save_name)
                            break
                    except errors.NoDefinedSaveError:
                        console.print('[bold red]Ошибка нету последнего сохранения')
                        continue
                else:
                    console.print('[bold red]Ошибка нету последнего сохранения')
                    continue
            elif self.choice == OPEN_SETTINGS:
                while True:
                    self.menu_options()
                    self.show_options()
                    self.option_command = str(
                        Input(
                            text="[bold red]> ",
                        )
                    )
                    option_name_cheack = False
                    if self.option_command.split(" ")[0] in commands3:
                        option_name_cheack = True
                    else:
                        if self.option_command != 'e':
                            console.print('[bold red]Неизвестная команда')
                    if option_name_cheack and self.option_command != 'e':
                        if self.option_command.split(" ")[0] == 'set':
                            if len(self.option_command.split(" ")) == 3:
                                self.option_name = self.option_command.split(" ")[1]
                                if self.option_command.split(" ")[2].lower() == 'true':
                                    self.option_value = True
                                elif self.option_command.split(" ")[2].lower() == 'false':
                                    self.option_value = False
                                importer.settings[self.option_name] = self.option_value
                                console.print(f'[bold green]Изменено[/bold green] [bold white]{self.option_command.split(" ")[1]}[/bold white] - ' +
                                              '[bold red]false' if not importer.settings[self.option_command.split(" ")[1]] else '[bold green]true')
                            else:
                                console.print('[bold red]Нет допустимых параметров')
                        elif self.option_command.split(" ")[0] == 'def':
                            if len(self.option_command.split(" ")) == 2:
                                importer.settings[self.option_command.split(" ")[1]] = importer.default_settings[self.option_command.split(" ")[1]]
                                console.print(f'[bold green]Изменено по умолчанию[/bold green] [bold white]{self.option_command.split(" ")[1]}[/bold white] - ', end="")
                                console.print('[bold red]false' if not importer.default_settings[self.option_command.split(" ")[1]] else '[bold green]true')
                            else:
                                console.print('[bold red]Нет допустимых параметров')
                        elif self.option_command.split(" ")[0] == 'defall':
                            if len(self.option_command.split(" ")) == 1:
                                importer.settings = importer.default_settings
                                console.print('[bold green]Изменено по умолчанию все настройки')
                            else:
                                console.print('[bold red]Недопустимые параметры')

                        elif self.option_command.split(" ")[0] == 'save_exit':
                            importer.update_settings()
                            console.print('[bold green]Настройки сохранены')
                            self.main_menu()
                            break
                    elif self.option_command != 'e':
                        self.main_menu()
            elif self.choice == EXIT:
                raise KeyboardInterrupt
    def credits(self):
        if importer.settings["play_animation"]:
            sleep(1)
            console.print("[bold blue]Разработчики:[/bold blue]")
            sleep(1)
            console.print("[green]@TheHakerTech\n@MaksimKoreshkin[/green]")
            console.print("[bold blue]Помощь в разработке:[/bold blue]")
            sleep(1)
            console.print("[green]@kotazzz[/green]")
            console.print("[bold blue]Тестеры:[/bold blue]")
            sleep(1)
            console.print("[green]@TheHakerTech\n@MaksimKoreshkin\n@kotazzz[/green]")
            sleep(1)
        else:
            console.print("[bold blue]Разработчики:[/bold blue]")
            console.print("[green]@TheHakerTech\n@MaksimKoreshkin[/green]")
            console.print("[bold blue]Помощь в разработке:[/bold blue]")
            console.print("[green]@kotazzz[/green]")
            console.print("[bold blue]Тестеры:[/bold blue]")
            console.print("[green]@TheHakerTech\n@MaksimKoreshkin\n@kotazzz[/green]")

    def show_options(self):
        for (name, value) in importer.settings.items():
            console.print(f'[blue]{name}[/blue] {importer.settings_descriptions[name]} - ' + '[bold red]false' if not value else f'[blue]{name}[/blue] {importer.settings_descriptions[name]} - ' + '[bold green]true')

    def menu_options(self):
        console.print('[bold green]Настройки[/bold green] ([red]e[/red] - отмена)')
        for ch in (
            "      [blue]set[/blue] - Задать значение           (set <название> <значение true/false>)",
            "      [blue]def[/blue] - Сбросить по умолчанию     (def <название>)",
            "   [blue]defall[/blue] - Сбросить всё по умолчанию (defall)",
            "[blue]save_exit[/blue] - Сохранить настройки       (save-exit)\n"
        ):
            console.print(ch)

    def main_menu(self):
        for ch in (
            "   [blue]load[/blue] - Загрузить сохранение",
            "   [blue]last[/blue] - Последние сохранение",
            "[blue]credits[/blue] - Список разработчиков и благодарностей",
            "    [blue]new[/blue] - Новое сохранение",
            "[blue]options[/blue] - Настройки",
            "   [blue]exit[/blue] - Выход (Ctrl+C)"
        ):
            console.print(ch)


class Player(entity.PlayableEntity):
    def __init__(
        self,
        xp: float,
        damage: float,
        name: str,
        armors: list or tuple,
        soul_count: TheSoul,
        void_count: TheVoid,
        currency_count: c,
        items: list,
        skills: dict,
        description,
        block_damage,
    ):
        # Init params
        self.spawnpoint = None
        self.xp = xp
        self.full_xp = xp
        self.damage = damage
        self.name = name
        self.armors = armors
        self.soul_count = soul_count
        self.void_count = void_count
        self.currency_count = currency_count
        self.description = description
        self.skills = skills
        self.after_death = ""
        self.items = {k : v for (k, v) in zip(
            [item.name for item in items],
            items
        )}

        # Reinit params with changes
        self.block_damage = block_damage
        for armor in self.armors:
            self.block_damage = self.block_damage + armor.block_damage
        

    def __doc__(self):
        return str(self.description)


class Save():
    def __init__(self, player, total_location, save_name):
        self.save_name = save_name
        self.player = player
        """if total_location != None: # Если сохранение было создано
            self.total_location = LOCATION # Назначаем текущей локации значение начальной локации
            self.player.spawnpoint = self.total_location # Задаём спавнпоинт
        else:
            self.total_location = total_location"""
        self.total_location = total_location
        self.main()

    def main(self):
        # Modules settings
        items.player = self.player
        console.print(self.player.__doc__())
        save_game(self.save_name, {
            "player":self.player,
            "save"  :self
        })
        correct_command = lambda: len(self.choice.split(" ")) >= 2
        correct_command2 = lambda: len(self.choice.split(" ")) == 1
        # Выводим меню
        self.menu()
        while True:
            self.choice = str(
                Input(
                    "[bold red]> ",
                    correct=lambda x: str(x).lower().split(" ")[0]
                    in commands2
                    + [str(ch) for ch in range(1, len(self.total_location.names))],
                )
            ).lower()
            
            self.command = self.choice.lower().split(" ")[0]
            
            if self.command == INV and correct_command2():  # Вещи
                self.inventory(self.player)  # Открыть инвентарь
            elif self.command == LOCS and correct_command2():  # Локации
                self.show_locations()  # Показать локации
            elif self.command == SKILLS and correct_command2(): # Способности
                self.show_skills(self.player) # Показать способности
            elif self.command == SAVE and correct_command2():
                save_game(self.save_name, {
                    "save"  :self
                })
                console.print("[bold green]Сохранено")

            elif self.command == TALK and correct_command():  # Поговорить
                self.arg = str(self.choice).lower().split(" ")[1]
                self.talk(self.arg)
            elif self.command == FIGHT and correct_command():  # Сразится
                self.arg = str(self.choice).lower().split(" ")[1]
                self.fight(self.arg)
            elif self.command == QUIT and correct_command2():

                if not isinstance(self.total_location.parent, location.BasicLocation) and self.total_location.parent.quitable:
                    self.total_location = self.total_location.parent
                    self.total_location.located(self)
                elif not self.total_location.parent.quitable and self.total_location.parent.on_try_quit != None:
                    self.total_location.parent.on_try_quit(self)
                self.show_locations()

            elif self.command == GO and correct_command():
                self.arg = str(self.choice).lower().split(" ")[1]

                if self.arg in self.total_location.names.keys():
                    if isinstance(names_dict[self.total_location.names[self.arg].name], location.Door):
                        if names_dict[self.total_location.names[self.arg].name].key_item.name in self.player.items.keys():
                            if names_dict[self.total_location.names[self.arg].name].on_into_func != None:
                                names_dict[self.total_location.names[self.arg].name].on_into_func(self)
                            self.total_location = names_dict[self.total_location.names[self.arg].name].underloc
                            self.total_location.located(self)
                            if self.total_location.on_into_func != None:
                                self.total_location.on_into_func(self)
                        else:
                            console.print(f"[bold red]Чтобы пройти, вам нужно {names_dict[self.total_location.names[self.arg].name].key_item.name}")
                    elif isinstance(names_dict[self.total_location.names[self.arg].name], location.Location):
                        self.total_location = names_dict[self.total_location.names[self.arg].name]
                        self.total_location.located(self)
                        if self.total_location.on_into_func != None:
                            self.total_location.on_into_func(self)
                    self.show_locations()
                else:
                    console.print("[bold red]Введено неверное число")
                    self.show_locations()
            elif self.command == EXIT and correct_command2():
                raise KeyboardInterrupt
            elif self.command == HELP:
                self.menu()
    def show_skills(self, _entity: entity.PlayableEntity or entity.NotPlayableEntity):
        d = str()
        for skill_name in _entity.skills:
            console.print(
                f"[bold white]{_entity.skills[skill_name][0].name}[/bold white] - [blue]{skill_name}.[/blue] [yellow]{_entity.skills[skill_name][1]}[/yellow]"
            )
            d += f"{skill_name} - {_entity.skills[skill_name][0].name}. {_entity.skills[skill_name][1]},\n"
        return d

    def _exit(self):
        print("^C")
        console.print("[bold red]Вы действительно хотите выйти?[/bold red][y/n]")
        is_exit = str(
            Input(text="[bold red]> ", correct=lambda x: str(x).lower() in ("y", "n"))
        )
        if is_exit.lower() == "y":
            save_game(self.save_name, {
                "player":self.player,
                "save"  :self
            })
            console.log("[bold green]Сохранено")

        elif is_exit.lower() == "n":
            pass

    def correct_attack(self, attack: str):
        if len(attack) <= 2:
            result = False
            for n in attack.upper():
                if n in self.player.skills:
                    result = True
                else:
                    result = False
            return result
        else:
            return False


    def fight(self, entity_name):
        if self.arg in self.total_location.ent_names:
            if (
                self.total_location.ent_names[self.arg].identifier
                == entity.EntType.BOSS
            ):
                enemy = self.total_location.ent_names[entity_name]
                enemy.start_dialog()
                console.print(f"[bold white]Сразится с [bold red]{enemy.name}[/bold red]? [y/n]")
                answer = str(
                    Input(
                        text="[bold red]> ",
                        correct=lambda x: str(x) in ("y", "n"),
                    )
                )
                if answer == "y":
                    console.print('Ваши способности')
                    self.show_skills(self.player)
                    console.print('Способности врага')
                    self.show_skills(enemy)
                    console.print(f"[bold red]Введите аттаку[/bold red]\n")
                    while True:
                        self.attack = str(
                            Input(
                                text="[bold red]> ",
                                correct=lambda x: str(x).upper()
                                in self.player.skills,
                            )
                        ).upper()
                        enemy.update_attack()
                        atk = self.attack
                        console.print('[bold green]Вы:', self.player.skills[atk][0].name)
                        console.print('[bold green]Враг:', enemy.skills[enemy.attack][0].name)
                        
                        if ( # У нас щит а у врага оружие
                            isinstance(self.player.skills[atk][0], items.Shield) and
                            isinstance(enemy.skills[enemy.attack][0], items.Weapon)
                        ):
                            console.print("[bold white]Вы отразили удар")
                        if ( # У врага щит а у нас оружие
                            isinstance(enemy.skills[enemy.attack][0], items.Shield) and
                            isinstance(self.player.skills[atk][0], items.Weapon)
                        ):
                            console.print("[bold white]Противник отразил удар")
                        if ( # У нас оружие а у врага оружие
                            isinstance(self.player.skills[atk][0], items.Weapon) and
                            isinstance(enemy.skills[enemy.attack][0], items.Weapon)
                        ):
                            a = enemy.hit(self.player.skills[atk][0])
                            b = self.player.hit(enemy.skills[enemy.attack][0])
                            console.print(f"Вы нанесли: {a[1]}\t {round(enemy.xp, 1)}/{round(enemy.full_xp, 1)}")  
                            console.print(f"Вам нанесли: {b[1]}\t {round(self.player.xp, 1)}/{round(self.player.full_xp, 1)}")
                        if ( # У врага оружие а у нас скилл
                            isinstance(enemy.skills[enemy.attack][0], items.Weapon) and
                            isinstance(self.player.skills[atk][0], items.Skill)
                        ):
                            if enemy.skills[enemy.attack][0].name in [ref.name for ref in self.player.skills[atk][0].reflecs]:
                                console.print("[bold white]Вы увернулись")
                            else:
                                b = self.player.hit(enemy.skills[enemy.attack][0])
                                console.print(f"Вам нанесли: {b[1]}\t {round(self.player.xp, 1)}/{round(self.player.full_xp, 1)}")
                        if ( # У нас оружие а у врага скилл
                            isinstance(self.player.skills[atk][0], items.Weapon) and
                            isinstance(enemy.skills[enemy.attack][0], items.Skill)
                        ):
                            if self.player.skills[atk][0].name in [ref.name for ref in enemy.skills[enemy.attack][0].reflecs]:
                                console.print("[bold white]Противник увернулся")
                            else:
                                a = enemy.hit(self.player.skills[atk][0])
                                console.print(f"Вы нанесли: {a[1]}\t {round(enemy.xp, 1)}/{round(enemy.full_xp, 1)}")
                        if ( # У нас скилл а у врага скилл
                            isinstance(self.player.skills[atk][0], items.Skill) and
                            isinstance(enemy.skills[enemy.attack][0], items.Skill)
                        ):
                            console.print("[bold white]Противник увернулся")
                            console.print("[bold white]Вы увернулись")
                        if enemy.xp <= 0 or self.player.xp <= 0:
                            break
                    if self.player.xp <= 0:
                        console.print(f"[bold red]Вы умерли")
                        sleep(1)
                        console.print(f"[bold white]...")
                        sleep(1)
                        console.print(f"[bold green]Вы возродились")
                        self.total_location = self.player.spawnpoint
                        self.show_locations()
                    else:
                        enemy.death_event(enemy.after_death)
                        console.print(f"[bold yellow]Вы победили[/bold yellow] [bold red]{enemy.name}")
                        if isinstance(enemy.drop, c):
                            console.print(f"[bold white]Вы получили {enemy.drop.num}{enemy.drop.name}[/bold white]")
                            self.player.currency_count.num += enemy.drop.num
                        else:
                            console.print(f"[bold white]Вы получили {enemy.drop.name}[/bold white] [bold yellow]{enemy.drop.description}")
                            enemy.drop.received()
                            self.player.items[enemy.drop.name] = enemy.drop
                        del self.total_location.entities[enemy.name]


    def talk(self, entity_name):
        if self.total_location.ent_names[entity_name].identifier == entity.EntType.NPC:
            self.total_location.ent_names[entity_name].start_dialog()
        elif self.total_location.ent_names[entity_name].identifier == entity.EntType.SEILER:
            self.total_location.ent_names[entity_name].start_dialog()
            self.total_location.ent_names[entity_name].shop.show(self.player.currency_count)
            console.print("[red]e[/red] - выход")
            while True:
                self.choice_item = Input("[bold red]> ")
                if str(self.choice_item).lower() == "e":
                    console.print("[bold red]Вы вышли")
                    self.show_locations()
                    break
                elif str(self.choice_item) in [str(x) for x in range(1, len(self.total_location.ent_names[entity_name].shop.items) + 1)]:
                    item_sum = self.total_location.ent_names[entity_name].shop.items[str(self.choice_item)][1]
                    if self.player.currency_count.num >= item_sum.num:
                        buy_item = self.total_location.ent_names[entity_name].shop.buy(str(self.choice_item))
                        if isinstance(buy_item, items.Weapon):
                            self.player.items[buy_item.name] = buy_item 
                            self.player.skills[str(buy_item.controle)] = (buy_item, buy_item.description)
                        self.player.currency_count.num -= item_sum.num
                else:
                    console.print("[bold red]Неверный параметр")
    def show_locations(self):
        # Показать текущию
        console.print(f"[bold green]Текущая локация[/bold green][bold white] {self.total_location.name}")
        # Если есть подлокации
        if self.total_location.underlocs != dict():
            
            # Показать подлокации
            console.print("[bold green]Подлокации[/bold green]")
            self.loc_index = 0
            for num in self.total_location.names: # Циклом перебераем подлокации
                console.print(
                    f"[blue]{num}[/blue][bold white] - {self.total_location.names[num].name}[/bold white] [bold yellow]{self.total_location.names[num].description}[/bold yellow]"
                )
                self.loc_index += 1

            if not isinstance(self.total_location.parent, location.BasicLocation):
                console.print(
                    f"[blue]quit[/blue][bold white] - {self.total_location.parent.name}[/bold white] (Выход)"
                )
        # Вывод существ
        # Проверяем, есть ли существа в текущей локации
        if self.total_location.entities != dict():
            console.print(f"[bold green]Существа")
            for num, name in enumerate(self.total_location.entities, 1):
                ent = self.total_location.entities[name]
                console.print(
                    f"[blue]{num}[/blue][bold white] - {ent.name}[/bold white] [bold yellow]{ent.description}[/bold yellow]"
                )

    def inventory(self, _entity: entity.PlayableEntity or entity.NotPlayableEntity):
        console.print("[bold green]Вещи")
        for item_name in _entity.items:
            console.print(
                f"[bold white]{item_name}[/bold white] [blue]{_entity.items[item_name].description}.[/blue]\
                    [yellow]{_entity.items[item_name].interesting}[/yellow]"
            )
        if isinstance(_entity, Player):
            console.print(f"")

    def menu(self):
        for ch in (
            "  [blue]help[/blue] - Показать список команд",
            "   [blue]inv[/blue] - Вещи              (inv)",
            "  [blue]locs[/blue] - Доступные локации (locs)",
            "[blue]skills[/blue] - Навыки            (skills)",
            "  [blue]talk[/blue] - Поговорить        (talk <номер персонажа>)",
            " [blue]fight[/blue] - Сразиться         (fight)",
            "  [blue]save[/blue] - Сохранить         (save)",
            "    [blue]go[/blue] - Переместиться     (go <номер локации>)",
            "  [blue]exit[/blue] - Выход (Ctrl+C)    (выход)",
            "  [blue]quit[/blue] - Выйти назад в предыдущию локацию"
        ):
            console.print(ch)

if __name__ == "__main__":
    while True:
        try:
            game = Game()
        except KeyboardInterrupt:
            print("^C")
            console.print("[bold red]Вы действительно хотите выйти?[/bold red][y/n]")
            is_exit = str(
                Input(
                    text="[bold red]> ", correct=lambda x: str(x).lower() in ("y", "n")
                )
            )
            if is_exit.lower() == "y":
                break

            elif is_exit.lower() == "n":
                continue
