# -*- coding: utf-8 -*-
class SaveIsNotDictError(Exception): pass
class NoDefinedSaveError(Exception): pass