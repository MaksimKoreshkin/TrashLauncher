# -*- coding: utf-8 -*-
import json
settings_descriptions = {
    'play_animation': 'Вкл./Выкл. анимации текста',
    'time': 'Вкл./Выкл. счётчик времени игры'
}

settings = {
    'play_animation': False,
    'time': False
}

default_settings = {
    'play_animation': True,
    'time': True
}

def load_settings():
    global settings
    settings_file = open(r'data/settings.json', 'r') 
    settings = json.loads(settings_file.read())
    settings_file.close()

def update_settings():
    global settings
    settings_file = open(r'data/settings.json', 'w')
    settings_file.write(json.dumps(settings, skipkeys=True))
    settings_file.close()