from rich.console import Console
from modules.currency import Currency as c


console = Console()


class Shop:
    def __init__(self, items: dict):
        self.items = {str(num):(items[name][0], items[name][1]) for (num, name) in enumerate(items.keys(), start=1)}
        
    def show(self, money: c):
        self.player_money = money
        console.print("[bold greed]Магазин:")
        self.items = {str(num):(self.items[name][0], self.items[name][1]) for (num, name) in enumerate(self.items.keys(), start=1)}
        for num in self.items.keys():

            sum = f"[bold red]{str(self.items[num][1].num)+str(c(0).name)}[/bold red]" if int(self.items[num][1].num) > self.player_money.num else f"[bold green]{str(self.items[num][1].num)+str(c(0).name)}[/bold green]"
            console.print(f"{num} - {self.items[num][0].name} {sum}")

    def buy(self, num):
        console.print(f"[bold white]Куплено: [/bold white]{self.items[str(num)][0].name}")
        buy_item = self.items[str(num)][0]
        del self.items[str(num)]
        self.show(self.player_money)
        return buy_item
        