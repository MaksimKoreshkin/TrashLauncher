# -*- coding: utf-8 -*-
"""
Module with class for location - Location
"""
locations_dict = {}


class BasicLocation:
    def __init__(self):

        self.name = "basic"


class Location:
    def __init__(
        self,
        name: str,
        entities: dict,  
        hardlevel: int,
        description, 
        underlocs=dict(),
        on_into_func=None,
        quitable=True,
        on_try_quit=None,
        located_func=None
    ):
        """
        Busic class for locations. Parameters:
        -`name` str location name
        -`hardlevel` int location hardlevel
        -`description` location description
        All parameters are requared
        """
        self.name = name
        self.underlocs = underlocs
        self.on_into_func = on_into_func
        self.quitable = quitable
        self.parent = BasicLocation()
        self.entities = entities
        self.on_try_quit = on_try_quit
        self.located_func = located_func

        self.ent_names = {str(k): v for (k, v) in enumerate(self.entities.values(), 1)}
        self.names = {str(k): v for (k, v) in enumerate(self.underlocs.values(), 1)}

        self.hardlevel = hardlevel
        self.description = description
        self.is_located = False
        locations_dict[self.name] = self

    def doc(self):
        return str(self.description)

    def located(self, obj):
        #if not self.is_located:
        #    self.is_located = True
        if self.located_func != None:
            self.located_func(obj)

    def add(self, location, r=True):
        self.underlocs[location.name] = location
        if r:
            return location
        else:
            return self
    
    def addr(self, location, r=False):
        self.underlocs[location.name] = location
        if r:
            return location
        else:
            return self
        
class Door(Location):
    def __init__(
        self,
        name: str,
        key_item,
        underloc=None,
        parent=None,
        on_into_func=None,
        description=""
    ):
        self.parent = parent
        self.name = name
        self.underloc = underloc
        self.key_item = key_item
        self.description = description
        locations_dict[self.name] = self