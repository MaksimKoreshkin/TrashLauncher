# -*- coding: utf-8 -*-
import shutil
from rich.console import Console
import zipfile
import os
import shlex
from time import sleep
import requests

console = Console(highlight=False)

os.system("")





              

LOGO = """
╔════╗╔═══╗╔══╗╔══╗╔╗╔╗───╔╗──╔══╗╔╗╔╗╔╗─╔╗╔══╗╔╗╔╗╔═══╗╔═══╗
╚═╗╔═╝║╔═╗║║╔╗║║╔═╝║║║║───║║──║╔╗║║║║║║╚═╝║║╔═╝║║║║║╔══╝║╔═╗║
──║║──║╚═╝║║╚╝║║╚═╗║╚╝║───║║──║╚╝║║║║║║╔╗─║║║──║╚╝║║╚══╗║╚═╝║
──║║──║╔╗╔╝║╔╗║╚═╗║║╔╗║───║║──║╔╗║║║║║║║╚╗║║║──║╔╗║║╔══╝║╔╗╔╝
──║║──║║║║─║║║║╔═╝║║║║║───║╚═╗║║║║║╚╝║║║─║║║╚═╗║║║║║╚══╗║║║║─
──╚╝──╚╝╚╝─╚╝╚╝╚══╝╚╝╚╝───╚══╝╚╝╚╝╚══╝╚╝─╚╝╚══╝╚╝╚╝╚═══╝╚╝╚╝─
"""
def zip_location(game_name):
    folders = []
    for folder in os.listdir("Games"):
        folder = os.path.join("Games", folder)
        if os.path.isdir(folder) and folder.endswith(game_name):
            folders.append(folder)
    return folders[0]


def download(url, filename, path=None):
    if path == None:
        response = requests.get(url)
        open(filename, "wb").write(response.content)
    else:
        if os.path.exists(path):
            if os.path.exists(f"{path}\{filename}"):
                os.remove(f"{path}\{filename}")
            response = requests.get(url)
            open(filename, "wb").write(response.content)
            shutil.move(filename, path)

def download_all_upgrades(name):
    getted_path = zip_location(name)
    download(url=f"https://raw.githubusercontent.com/MaksimKoreshkin/TrashLauncher/main/updates/{name}/meta.info", filename="meta.info", path=getted_path)
    download(url=f"https://raw.githubusercontent.com/MaksimKoreshkin/TrashLauncher/main/updates/{name}/game.zip", filename="game.zip", path=getted_path)


def parse_meta(meta_file):
    meta = open(meta_file, "r", encoding="UTF-8").read()
    allowed = ["name", "version", "author", "description"]
    lines = meta.splitlines()
    result = {}
    for line in lines:
        splited = shlex.split(line)
        if len(splited) != 2:
            raise Exception(f"Invalid meta.info: invalid line {line!r}")
        if splited[0] in allowed:
            result[splited[0]] = splited[1] 
        else:
            raise Exception(f"Invalid meta.info: {splited[0]} not allowed")
    return result
            

def get_packages():
    folders = []
    for folder in os.listdir("Games"):
        folder = os.path.join("Games", folder)
        if os.path.isdir(folder):
            folders.append(folder)
    meta_files = [os.path.join(folder, "meta.info") for folder in folders]
    meta = [parse_meta(meta_file) for meta_file in meta_files]
    zips = [os.path.join(folder, "game.zip") for folder in folders]
    return [{**meta, "zip": zip} for meta, zip in zip(meta, zips) if os.path.exists(zip)]


def get_installed():
    if not os.path.exists("launcher.cache"):
        open("launcher.cache", "w").close()
    data = open("launcher.cache", "r").read()
    installed = {}
    for line in data.splitlines():
        package, version, path = shlex.split(line)
        installed[package] = (version, path)
    return installed

def rewrite_installed(package, version, path):
    installed = get_installed()
    if version:
        installed[package] = (version, path)
    else:
        installed.pop(package)
    
    with open("launcher.cache", "w") as f:
        for package, (version, path) in installed.items():
            f.write(f"'{package}' '{version}' '{path}'\n")
    

def compare_versions(version1, version2):
    # 1.2.3 format
    version1 = version1.split(".")
    version2 = version2.split(".")
    for v1, v2 in zip(version1, version2):
        if int(v1) > int(v2):
            return 1 # v1 новее
        elif int(v1) < int(v2):
            return -1 # v2 новее, v1 устарел
    return 0 # версии одинаковые

def controlled(prompt, check):
    # Допытываем пользователя, пока не сработает check
    while True:
        # Сохраняем позицию курсора
        print("\033[s", end="")
        result = console.input(f"[blue]{prompt}[/]")
        if check(result):
            return result
        # Возвращаем курсор на место и чистим все, что под курсором
        print("\033[u\033[J", end="")

def main():
    download_all_upgrades("RPG") #Качает последнию версию RPG в папку Games/RPG
    console.print(LOGO, justify="center")
    console.print("Made by CraftBox", justify="center")
    packages = get_packages()
    installed = get_installed()
    for i, package in enumerate(packages, 1):
        # Выводим информацию о пакете
        author = package['author'] if 'author' in package else 'Unknown'
        description = package['description'] if 'description' in package else 'No description'
        name = package['name']
        version = package['version']
        console.print(f"[[green]{i}[/]] [yellow]{name} [green]{version} [white]by {author} - [cyan]{description}")
        # Если пакет установлен, выводим информацию о нем
        if package['name'] in installed:
            version, path = installed[package['name']]
            compare = compare_versions(version, package['version'])
            if compare == -1:
                console.print(f"    [yellow]Доступно обновление[/]: {package['version']} (Установлено [green]{version}[/])")
            elif compare == 1:
                console.print(f"    [red]У вас установлена более новая версия[/]: [green]{version}[/]")
            else:
                console.print(f"    [green]Установлено[/]: [green]{version}[/]")
            console.print(f"    [blue]Путь[/]: {path}")
        else:
            console.print("    [red]Не установлено[/]")
    
    
    console.print("\nВведите номер игры, что бы выполнить действие")
    select = controlled("> ", lambda x: x.isdigit() and int(x) in range(1, len(packages) + 1))
    package = packages[int(select) - 1]
    if package['name'] in installed:
        version, path = installed[package['name']]
        console.print("\nОбновить - u, Удалить - d, Запустить - r")
        select = controlled("> ", lambda x: x in "udr")
        if select == "u":
            compare = compare_versions(version, package['version'])
            if compare == -1:
                console.print(f"Доступно обновление {package['version']} (Установлено [green]{version}[/])")
                console.print(f"Путь: {path}")
                # remove old version
                shutil.rmtree(path)
                # unpack new version
                with zipfile.ZipFile(package['zip']) as zip:
                    zip.extractall(path)
                rewrite_installed(package['name'], package['version'], path)
                console.print("Успешно установлено")
            elif compare == 1:
                console.print(f"У вас установлена более новая версия: [green]{version}[/]")
            else:
                console.print(f"Установлено: [green]{version}[/]")
                console.print(f"Путь: [blue]{path}[/]")
        elif select == "d":
            print(path)
            shutil.rmtree(path)
            rewrite_installed(package['name'], None, None)
            console.print("Успешно удалено")
        elif select == "r":
            # path + / / p.py
            path = os.path.join(path, "p.py")
            os.startfile(path)
    else:
        console.print(f"Доступна установка [green]{package['version']}[/]")
        console.print(f"Путь до установочного файла: [blue]{package['zip']}")
        console.print(f"Путь установки: ([green]d[/] - что бы выбрать по умолчанию)")
        # default = ./Installed/name
        default = os.path.join("Installed")
        while True:
            def check(x):
                # если это путь (даже если он не существует)
                if os.path.isdir(x) or x=="d":
                    return x
                return False
            select = controlled("> ", check)
            if select == "d":
                path = default
            else:
                path = select
            console.print(f"Установить в [blue]{path}[/]? (y/n)")
            if controlled("> ", lambda x: x in "yn") == "y":
                break
        # makedir with packet name
        game_path = os.path.join(os.getcwd(), path, package['name'])
        
        os.makedirs(game_path, exist_ok=True)
        # unpack
        with zipfile.ZipFile(package['zip']) as zip:
            zip.extractall(game_path)
        rewrite_installed(package['name'], package['version'], game_path)
            
        
                
            
    
    
    
if __name__ == "__main__":
    # enter second buffer
    print("\033[?1049h")
    while True:
        try:
            # clear screen and go 0,0
            print("\033[2J\033[0;0H")
            main()
        except KeyboardInterrupt:
            break
    # exit second buffer
    print("\033[?1049l")
